#variable globale

$fqdn = Get-ADDomain
$fulldomain = $fqdn.DNSRoot
$domain = $fulldomain.Split(".")
$Dom  = $domain[0] 
$Dom1 = $fulldomain.Split(".")[0]
$EXT  = $domain[1]
$EXT1 = $(Get-ADDomain).DNSRoot.Split(".")[1]

$OUpremierNiveau = 'ETP Chasseneuil'
$OUsecondNiveaux = @('Administration','Adh�rants','Clients Entreprises','Groupes')

$ClientsName        = @('Esporting','ValorElec','LogistiX')
$DivisionStruct = @('Utilisateurs','Ordinateurs')

$Groupes         = @('Groupes globaux','Groupes domaine locaux')




function Create-Group {
    param(
    [Parameter(Position = 0)]
	[string[]] $TypeGroupe,
    [Parameter()]
	[string[]] $RelativePathOU,
    [Parameter()]
	[string[]] $depart
    )
    $depart = $depart.replace(" ","_")
    switch ($TypeGroupe) {
        'Groupes globaux' { 
                New-ADGroup -Name "Gg_$depart" -DisplayName "G_$depart" -GroupScope Global -GroupCategory Security -Path $RelativePathOU+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -Description "Groupe Global $depart"
                
        }
        'Groupes domaine locaux' {
                New-ADGroup -Name "DL_$depart`_L" -DisplayName "DL_$depart`_L" -GroupScope Global -GroupCategory Security -Path $RelativePathOU+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -Description "Groupe Domaine local $depart Lecture"
                New-ADGroup -Name "DL_$depart`_LM" -DisplayName "DL_$depart`_LM" -GroupScope Global -GroupCategory Security -Path $RelativePathOU+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -Description "Groupe Domaine local $depart Lecture et modification"
                New-ADGroup -Name "DL_$depart`_CT" -DisplayName "DL_$depart`_CT" -GroupScope Global -GroupCategory Security -Path $RelativePathOU+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -Description "Groupe Domaine local $depart controle totale" 
        }
        Default {}
    }

}

function Create-User {

	
	param(

		[Parameter(Position = 0)]
		[string[]] $TargetStageOU,

		[Parameter()]
		[string[]] $RelativePathOU
	)

	$nameFile=".\"+$TargetStageOU+".csv"
    if(Test-Path -Path $nameFile){
	
	    $listUser = Import-Csv -Path $nameFile
	
		foreach($usr in $listUser){
		
			$newUserProperties = @{
                            	Name = "$($usr.NameFirst) $($user.NameLast)"
                            	City = "Chasseneuil"
                            	GivenName = $usr.NameFirst
                            	Surname = $user.NameLast
                            	Path = $RelativePathOU+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT"
                            	title = "Employees"
                            	department=$usr.Depart
                            	OfficePhone = $usr.Phone
                           	    MobilePhone = $usr.Cell
                            	Company="$Dom"
                            	EmailAddress="$($usr.NameFirst).$($user.NameLast)@$($fulldomain)"
                            	AccountPassword = (ConvertTo-SecureString $usr.Password -AsPlainText -Force)
                            	SamAccountName = $($usr.NameFirst).Substring(0,1)+$($user.NameLast)
                            	UserPrincipalName = "$(($usr.NameFirst).Substring(0,1)+$($user.NameLast))@$($fulldomain)"
                            	Enabled = $true
                        }
                        New-ADUser @newUserProperties
		
		 }
	}
	else
            {
             #"le fichier n'existe pas donc pas d'utilisateur a enregistr�" 
            }
}

function Create-Division{
    param(
        [Parameter(Position = 0)]
		[string[]] $NameDivision,

        [Parameter()]
		[string[]] $RelativePathOU
    )
    foreach ($categorie in $DivisionStruct){
        New-ADOrganizationalUnit -Name $categorie -Path $RelativePathOU+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -ProtectedFromAccidentalDeletion $false
    }

    Create-User -TargetStageOU $NameDivision -RelativePathOU "OU=Utilisateurs,Ou=$NameDivision"

    foreach($Grp in $Groupes){
					New-ADOrganizationalUnit -Name $Grp -Path $RelativePathOU+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -ProtectedFromAccidentalDeletion $false
                    $json = Get-Content -Path "\.divisionMap.json" -Raw | ConvertFrom-Json
                    foreach($depatement in $json.$NameDivision){
                        Create-Group -TypeGroupe $Grp -RelativePathOU "OU=$Grp,OU=$NameDivision" -depart $depatement
                    }
                    
	}
}



New-ADOrganizationalUnit -Name $OUpremierNiveau -ProtectedFromAccidentalDeletion $false

foreach ($OU in $OUsecondNiveaux) {
	New-ADOrganizationalUnit -Name $OU -Path "Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -ProtectedFromAccidentalDeletion $false
	
	switch ($OU) {
		'Groupes'{
				foreach($Grp in $Groupes){
					New-ADOrganizationalUnit -Name $Grp -Path "OU=$OU,Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -ProtectedFromAccidentalDeletion $false
                    Create-Group -TypeGroupe $Grp -RelativePathOU "OU=$Grp,OU=$OU" -depart "ETP Chasseneuil"
				}
        
			}
  		Default {
            Create-Division -NameDivision $OU -RelativePathOU "OU=$OU"
  
        }
    }

}

foreach ($client in $ClientsName){
    Create-Division -NameDivision $client -RelativePathOU "OU=$client,Ou=Clients Entreprises"
}

$Users = Get-ADUser -Filter 'department -like "*"' -Properties * -SearchBase "Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT"


#placement des utilisateurs dans leur groupe global cible
foreach ($item in $Users) {
    $departFormat = $item.department.replace(" ","_")
    $item | Add-ADPrincipalGroupMembership  -MemberOf "Gg_"+$departFormat

}