#variable globale

$fqdn = Get-ADDomain
$fulldomain = $fqdn.DNSRoot
$domain = $fulldomain.Split(".")
$Dom  = $domain[0] 
$Dom1 = $fulldomain.Split(".")[0]
$EXT  = $domain[1]
$EXT1 = $(Get-ADDomain).DNSRoot.Split(".")[1]

$OUpremierNiveau = 'ETP Chasseneuil'

$TargetPath = ",OU=ValorElec,Ou=Clients Entreprises"
$Groupes         = @('Groupes globaux','Groupes domaine locaux')
$depatmentValorElec = @("Direction ValorElec","R&D ValorElec","Commercial ValorElec")

function New-Password
{

$Alphabets = 'a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z'
$numbers = 0..9
$specialCharacters = '~,!,@,#,$,%,^,&,*,(,),>,<,?,\,/,_,-,=,+'
$array = @()
$array += $Alphabets.Split(',') | Get-Random -Count 4
$array[0] = $array[0].ToUpper()
$array[-1] = $array[-1].ToUpper()
$array += $numbers | Get-Random -Count 3
$array += $specialCharacters.Split(',') | Get-Random -Count 3
($array | Get-Random -Count $array.Count) -join ""
}

function Create-Group {
    param(
    [Parameter(Position = 0)]
	[string[]] $TypeGroupe,
    [Parameter()]
	[string[]] $RelativePathOU,
    [Parameter()]
	[string[]] $depart
    )
    $depart = $depart.replace(" ","_")
    switch ($TypeGroupe) {
        'Groupes globaux' { 
                New-ADGroup -Name "Gg_$depart" -DisplayName "G_$depart" -GroupScope Global -GroupCategory Security -Path $RelativePathOU+$TargetPath+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -Description "Groupe Global $depart"
                
        }
        'Groupes domaine locaux' {
                New-ADGroup -Name "DL_$depart`_L" -DisplayName "DL_$depart`_L" -GroupScope Global -GroupCategory Security -Path $RelativePathOU+$TargetPath+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -Description "Groupe Domaine local $depart Lecture"
                New-ADGroup -Name "DL_$depart`_LM" -DisplayName "DL_$depart`_LM" -GroupScope Global -GroupCategory Security -Path $RelativePathOU+$TargetPath+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -Description "Groupe Domaine local $depart Lecture et modification"
                New-ADGroup -Name "DL_$depart`_CT" -DisplayName "DL_$depart`_CT" -GroupScope Global -GroupCategory Security -Path $RelativePathOU+$TargetPath+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT" -Description "Groupe Domaine local $depart controle totale" 
        }
        Default {}
    }

}


function Create-User {

	
	$nameFile=".\ValorElec.csv"
    if(Test-Path -Path $nameFile){
	
	    $listUser = Import-Csv -Path $nameFile
	
		foreach($usr in $listUser){
            $userPassword = New-Password
		
			$newUserProperties = @{
                            	Name = "$($usr.NameFirst) $($user.NameLast)"
                            	City = "Chasseneuil"
                            	GivenName = $usr.NameFirst
                            	Surname = $user.NameLast
                            	Path = "OU=Utilisateurs"+$TargetPath+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT"
                            	title = "Employees"
                            	department=$usr.Depart
                            	OfficePhone = $usr.Phone
                           	    MobilePhone = $usr.Cell
                            	Company="$Dom"
                            	EmailAddress="$($usr.NameFirst).$($user.NameLast)@$($fulldomain)"
                            	AccountPassword = (ConvertTo-SecureString $userPassword -AsPlainText -Force)
                            	SamAccountName = $($usr.NameFirst).Substring(0,1)+$($user.NameLast)
                            	UserPrincipalName = "$(($usr.NameFirst).Substring(0,1)+$($user.NameLast))@$($fulldomain)"
                            	Enabled = $true
                        }
                        New-ADUser @newUserProperties

                     if(!(Test-Path -Path "C:\DocumentsUser\Employes\ValorElec\$usr.Depart"))
                    {
                         New-Item -Path "C:\DocumentsUser\Employes\ValorElec\$usr.Depart" -ItemType Directory | Out-Null
                    }
                    else
                    {
                      #"The directory exist" 
                    }

                    #Emplacement du Template 
                    $FilePathTemplate = "C:\Template\template.docx"

                    $WordDocument = Get-WordDocument -FilePath $FilePathTemplate

                    $FilePathInvoice = "C:\DocumentsUser\Employes\ValorElec\$usr.Depart\$($user.name.last) $($user.name.first).docx"
                    Add-WordText -WordDocument $WordDocument -Text 'Creation de Compte' -FontSize 15 -HeadingType Heading1 -FontFamily 'Arial' -Italic $true | Out-Null


                    Add-WordText -WordDocument $WordDocument -Text 'Voici les informations qui vous permettrons de vous connecter au Domaine Active Directory', " $fulldomain" `
                    -FontSize 12, 13 `
                    -Color Black, Blue `
                    -Bold $false, $true `
                    -SpacingBefore 15 `
                    -Supress $True

                    Add-WordText -WordDocument $WordDocument -Text 'Login : ', "$(($usr.NameFirst).Substring(0,1)+$($user.NameLast))" `
                    -FontSize 12, 10 `
                    -Color Black, Blue `
                    -Bold $false, $true `
                    -Supress $True

                    Add-WordText -WordDocument $WordDocument -Text 'Mot de passe : ',"$userPassword" `
                    -FontSize 12, 10 `
                    -Color Black, Blue `
                    -Bold $false, $true `
                    -Supress $True
                    Add-WordText -WordDocument $WordDocument -Text 'Adresse de messagerie : ',"$(($usr.NameFirst).Substring(0,1)+$($user.NameLast))@$($fulldomain)" `
                    -FontSize 12, 10 `
                    -Color Black, Blue `
                    -Bold $false, $true `
                    -SpacingAfter 15 `
                    -Supress $True

                                
                    Add-WordProtection -WordDocument $WordDocument -EditRestrictions readOnly -Password 'j89<yO&'

                    Save-WordDocument -WordDocument $WordDocument -FilePath $FilePathInvoice -Supress $true -Language 'fr-FR'
		
		 }
	}
	else
            {
             #"le fichier n'existe pas donc pas d'utilisateur a enregistr�" 
            }
}



foreach ($Grp in $Groupes){

    foreach ($depatement in $depatmentValorElec){
        Create-Group -TypeGroupe $Grp -RelativePathOU "OU=$Grp" -depart $depatement
    }
    

}


Create-User

$Users = Get-ADUser -Filter 'department -like "ValorElec"' -Properties * -SearchBase "OU=Utilisateurs"+$TargetPath+",Ou=$OUpremierNiveau,dc=$Dom,dc=$EXT"


#placement des utilisateurs dans leur groupe global cible
foreach ($item in $Users) {
    $departFormat = $item.department.replace(" ","_")
    $item | Add-ADPrincipalGroupMembership  -MemberOf "Gg_"+$departFormat

}