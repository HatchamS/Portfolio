﻿$depatmentValorElec = @("Direction_ValorElec","R&D_ValorElec","Commercial_ValorElec")

$PathRoot = "C:\Partage\ValorElec"

foreach($depart in $depatmentValorElec){

    # Creation du dossier personnel
    New-Item -ItemType Directory -Path "$PathRoot\$depart"

    # Desactiver l'heritage tout en copiant les autorisations NTFS héritées
    Get-Item "$PersonnelPathRoot\$depart" | Disable-NTFSAccessInheritance

    # Ajout des autorisations NTFS
    Add-NTFSAccess –Path "$PersonnelPathRoot\$depart"  –Account "DL_$depart`_CT" –AccessRights FullControl
    
    # Modifier le proprietaire sur le dossier
    Set-NTFSOwner -Path "$PersonnelPathRoot\$depart" -Account "DL_$depart`_CT"
    
    # Supprimer des autorisations NTFS pour tout le monde, non inclut dans groupe
    Remove-NTFSAccess –Path "$PersonnelPathRoot\$depart"  –Account "Utilisateurs" -AccessRights FullControl

}